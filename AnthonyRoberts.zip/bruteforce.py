# Team - Sphinx
# bruteforce.py
# Python 2.7

from os.path import isfile,join
import os
import math
import argparse

#File = 1843254
#size = int(math.ceil((File**0.5)**0.5))
#y = [1<<exponent for exponent in range(size) ]
#K = [i for i in y if (i < File)]

parser = argparse.ArgumentParser(prog='bruteforce.py',conflict_handler="resolve")
parser.add_argument("-o","--offset",default=1,nargs="+",help="Set offset to <val>",type=int)
parser.add_argument("-i","--interval",default=1,nargs="+",help=" Set interval to <val>",type=int)
args = parser.parse_args()
print args.interval

if type(args.interval)==int or len(args.interval) == 1 :
    I = args.interval if type(args.interval) ==list else [args.interval]    
    #I = [i for i in range(I,2048)]
elif len(args.interval)==2:
    I = [i for i in range(args.interval[0],args.interval[1]+1)]
elif len(args.interval )==3:
    I = [i for i in range(args.interval[0],args.interval[1]+1,args.interval[2])]
else:
   raise ValueError("Error: Interval value out of range")

if type(args.offset)==int or len(args.offset) == 1:
    O = args.offset if type(args.offset) ==list else[ args.offset]    
    #O = [i for i in range(O,2048)]
elif len(args.offset)==2:
    O = [i for i in range(args.offset[0],args.offset[1]+1)]
elif len(args.offset)==3:
    O = [i for i in range(args.offset[0],args.offset[1]+1,args.offset[2])]
else:
   raise ValueError("Error: Offset value out of range")

#O = [2**i for i in range(10)] if args.offset == None else [args.offset]
#I = [i for i in range(512,2048)] if args.interval == None else [args.interval]

#mypath = "~/Desktop/Programs/CYBERSTORM/Steg/bruteforceFiles/"
mypath= os.path.dirname(os.path.realpath(__file__))
mypath = join(mypath,'bruteforceFiles')
#print os.listdir(mypath)
#print isfile(join(mypath,'.bmp'))
FILES = [join(mypath, f) for f in os.listdir(mypath) if isfile(join(mypath, f))]
#FILES=[]
end = False
for o in O:
    if end:
        break
	
    for i in I:
       
        for f in FILES:
            os.system('python ~/Desktop/Programs/CYBERSTORM/Steg/steg.py -r -b -i{} -o{} -w{} --kind'.format(i,o,f))
            os.system('python ~/Desktop/Programs/CYBERSTORM/Steg/steg.py -r -B -i{} -o{} -w{} --kind'.format(i,o,f))
            print("Checked -i{} -o{}".format(i,o))
        

            
		    

        
        




